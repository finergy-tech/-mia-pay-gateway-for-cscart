<?php

if (!defined('AREA')) {
    die('Access denied');
}
